package de.unigoettingen.math.fingerprint.display.controller;

import de.unigoettingen.math.fingerprint.display.Deactivatable;

public interface RidgeFrequencyController extends Deactivatable, IController {
}
