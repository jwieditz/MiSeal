package de.unigoettingen.math.fingerprint.display.controller;

import de.unigoettingen.math.fingerprint.display.Deactivatable;

public interface DivergenceController extends Deactivatable, IController {
}
