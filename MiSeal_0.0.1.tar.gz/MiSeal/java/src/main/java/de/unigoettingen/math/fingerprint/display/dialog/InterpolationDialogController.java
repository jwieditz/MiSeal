package de.unigoettingen.math.fingerprint.display.dialog;

import de.unigoettingen.math.fingerprint.interpolation.Interpolation;

public interface InterpolationDialogController {
    Interpolation get();
}
