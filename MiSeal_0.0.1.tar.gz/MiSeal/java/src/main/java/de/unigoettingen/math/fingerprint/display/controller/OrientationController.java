package de.unigoettingen.math.fingerprint.display.controller;

public interface OrientationController extends IController {
}
