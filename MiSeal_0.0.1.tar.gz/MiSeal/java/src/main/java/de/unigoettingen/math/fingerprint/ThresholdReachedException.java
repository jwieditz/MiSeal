package de.unigoettingen.math.fingerprint;

public class ThresholdReachedException extends Exception {

    public ThresholdReachedException(String message) {
        super(message);
    }
}
