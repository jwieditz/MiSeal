package de.unigoettingen.math.fingerprint.display.dialog;

import de.unigoettingen.math.fingerprint.smoothing.Smoothing2D;

public interface Smoothing2DDialogController {

    Smoothing2D get();
}
