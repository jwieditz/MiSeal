package de.unigoettingen.math.fingerprint.display;

public interface Deactivatable {
    void setDeactivated(boolean deactivated);
}
