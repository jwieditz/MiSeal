package de.unigoettingen.math.fingerprint.display.dialog;

import de.unigoettingen.math.fingerprint.smoothing.Smoothing1D;

public interface Smoothing1DDialogController {
    Smoothing1D get();
}
