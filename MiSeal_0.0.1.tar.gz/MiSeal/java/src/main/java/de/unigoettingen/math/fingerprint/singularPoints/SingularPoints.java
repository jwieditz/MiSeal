package de.unigoettingen.math.fingerprint.singularPoints;

import de.unigoettingen.math.fingerprint.FingerprintImage;

public interface SingularPoints {

    void computeSingularPoints(FingerprintImage image);
}
