package de.unigoettingen.math.fingerprint.utilities.unwrap;

public enum UnwrapType {
    LINES,
    SPIRALS,
    DIAMOND;
}
