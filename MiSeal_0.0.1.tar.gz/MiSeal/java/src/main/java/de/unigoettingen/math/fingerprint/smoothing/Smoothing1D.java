package de.unigoettingen.math.fingerprint.smoothing;

public interface Smoothing1D {

    double smooth(int x, double[] data);
}
